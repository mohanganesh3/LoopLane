/**
 * Check and Update User Role
 * Run: node scripts/check-user-role.js <email> [new-role]
 */

const mongoose = require('mongoose');
const User = require('../models/User');

// Database connection
const connectDB = async () => {
    try {
        await mongoose.connect('mongodb://localhost:27017/looplane', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('✅ MongoDB Connected');
    } catch (error) {
        console.error('❌ MongoDB Connection Error:', error);
        process.exit(1);
    }
};

// Main function
const main = async () => {
    const email = process.argv[2];
    const newRole = process.argv[3];
    
    if (!email) {
        console.log('Usage: node scripts/check-user-role.js <email> [new-role]');
        console.log('Example: node scripts/check-user-role.js user@example.com RIDER');
        console.log('Valid roles: PASSENGER, RIDER, ADMIN');
        process.exit(1);
    }
    
    await connectDB();
    
    try {
        const user = await User.findOne({ email });
        
        if (!user) {
            console.log(`❌ User not found: ${email}`);
            process.exit(1);
        }
        
        console.log('\n📋 User Information:');
        console.log('─'.repeat(50));
        console.log(`Name: ${user.firstName} ${user.lastName}`);
        console.log(`Email: ${user.email}`);
        console.log(`Phone: ${user.phoneNumber}`);
        console.log(`Current Role: ${user.role}`);
        console.log(`Verification Status: ${user.verificationStatus}`);
        console.log(`Email Verified: ${user.isEmailVerified ? '✅' : '❌'}`);
        console.log(`Phone Verified: ${user.isPhoneVerified ? '✅' : '❌'}`);
        console.log(`Account Status: ${user.accountStatus}`);
        console.log(`Created: ${user.createdAt}`);
        
        // Update role if provided
        if (newRole) {
            const validRoles = ['PASSENGER', 'RIDER', 'ADMIN'];
            const upperRole = newRole.toUpperCase();
            
            if (!validRoles.includes(upperRole)) {
                console.log(`\n❌ Invalid role: ${newRole}`);
                console.log(`Valid roles: ${validRoles.join(', ')}`);
                process.exit(1);
            }
            
            user.role = upperRole;
            
            // If upgrading to RIDER and not verified, set to PENDING
            if (upperRole === 'RIDER' && user.verificationStatus === 'UNVERIFIED') {
                user.verificationStatus = 'PENDING';
            }
            
            await user.save();
            
            console.log('\n✅ Role Updated Successfully!');
            console.log(`New Role: ${user.role}`);
            console.log(`Verification Status: ${user.verificationStatus}`);
        }
        
        console.log('─'.repeat(50));
        
    } catch (error) {
        console.error('❌ Error:', error.message);
    }
    
    await mongoose.connection.close();
    console.log('\n✅ Database connection closed');
    process.exit(0);
};

// Run the script
main();
