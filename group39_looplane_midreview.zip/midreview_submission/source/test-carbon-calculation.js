/**
 * Test Carbon Calculation
 * This script tests the carbon calculation for riders and passengers
 */

require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Ride = require('./models/Ride');
const Booking = require('./models/Booking');
const carbonCalculator = require('./utils/carbonCalculator');
const connectDB = require('./config/database');

const testCarbonCalculation = async () => {
    try {
        console.log('🧪 Testing Carbon Calculation...\n');

        // Connect to database
        await connectDB();

        // Find a rider with completed rides
        const rider = await User.findOne({ role: 'RIDER' }).lean();
        if (!rider) {
            console.log('⚠️  No rider found in database');
        } else {
            console.log(`📊 Testing for RIDER: ${rider.name || rider.email}`);
            
            const riderCompletedRides = await Ride.countDocuments({
                rider: rider._id,
                status: 'COMPLETED'
            });
            console.log(`   Completed Rides: ${riderCompletedRides}`);

            if (riderCompletedRides > 0) {
                const riderReport = await carbonCalculator.generateUserCarbonReport(rider._id);
                console.log('\n   Carbon Report:');
                console.log(`   ✅ Total CO₂ Saved: ${riderReport.totalSaved} kg`);
                console.log(`   ✅ Total Distance: ${riderReport.totalDistance} km`);
                console.log(`   ✅ Total Trips: ${riderReport.totalTrips}`);
                console.log(`   ✅ Passengers Helped: ${riderReport.totalPassengersHelped}`);
                console.log(`   ✅ Trees Equivalent: ${riderReport.equivalentTrees}`);
                console.log(`   ✅ Badge: ${riderReport.badge.emoji} ${riderReport.badge.name}`);
                console.log(`   ✅ Average per Trip: ${riderReport.averagePerTrip} kg`);
            }
        }

        console.log('\n' + '='.repeat(60) + '\n');

        // Find a passenger with completed bookings
        const passenger = await User.findOne({ role: 'PASSENGER' }).lean();
        if (!passenger) {
            console.log('⚠️  No passenger found in database');
        } else {
            console.log(`📊 Testing for PASSENGER: ${passenger.name || passenger.email}`);
            
            const passengerCompletedBookings = await Booking.countDocuments({
                passenger: passenger._id,
                status: 'COMPLETED'
            });
            console.log(`   Completed Bookings: ${passengerCompletedBookings}`);

            if (passengerCompletedBookings > 0) {
                const passengerReport = await carbonCalculator.generateUserCarbonReport(passenger._id);
                console.log('\n   Carbon Report:');
                console.log(`   ✅ Total CO₂ Saved: ${passengerReport.totalSaved} kg`);
                console.log(`   ✅ Total Distance: ${passengerReport.totalDistance} km`);
                console.log(`   ✅ Total Trips: ${passengerReport.totalTrips}`);
                console.log(`   ✅ Trees Equivalent: ${passengerReport.equivalentTrees}`);
                console.log(`   ✅ Badge: ${passengerReport.badge.emoji} ${passengerReport.badge.name}`);
                console.log(`   ✅ Average per Trip: ${passengerReport.averagePerTrip} kg`);
            }
        }

        console.log('\n' + '='.repeat(60) + '\n');

        // Test manual calculation
        console.log('🧮 Manual Calculation Test:');
        console.log('   Scenario: 50km trip, SEDAN, PETROL, 3 passengers\n');
        
        const testResult = carbonCalculator.calculateCarbonSaved(50, 'SEDAN', 3, 'PETROL');
        console.log(`   Solo Emission (per car): ${testResult.soloEmission} kg`);
        console.log(`   Carpool Total Emission: ${testResult.carpoolEmission} kg`);
        console.log(`   Per Person in Carpool: ${testResult.perPersonEmission} kg`);
        console.log(`   Saved Per Person: ${testResult.savedPerPerson} kg`);
        console.log(`   Total CO₂ Saved: ${testResult.totalSaved} kg`);
        console.log(`   Trees Equivalent: ${testResult.equivalentTrees}`);
        console.log(`   Reduction: ${testResult.reductionPercentage}%`);
        console.log(`   Money Saved: ₹${testResult.moneySavedOnFuel}`);

        console.log('\n✅ Carbon calculation test completed!\n');
        process.exit(0);
    } catch (error) {
        console.error('❌ Test error:', error);
        console.error('Stack:', error.stack);
        process.exit(1);
    }
};

testCarbonCalculation();
