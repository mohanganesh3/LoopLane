/**
 * Test Forgot Password Flow
 * This script tests the complete forgot password functionality
 */

require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const emailService = require('./utils/emailService');

async function testForgotPassword() {
    try {
        console.log('🔵 Connecting to MongoDB...');
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/lane');
        console.log('✅ Connected to MongoDB\n');

        // Test 1: Find user
        console.log('📋 TEST 1: Find user by email');
        const testEmail = 'mohanganesh.g23@iiits.in';
        const user = await User.findOne({ email: testEmail });
        
        if (!user) {
            console.log('❌ User not found');
            process.exit(1);
        }
        console.log('✅ User found:', user.email);
        console.log('   - Name:', user.profile.firstName, user.profile.lastName);
        console.log('   - Email Verified:', user.emailVerified);
        console.log('   - Account Status:', user.accountStatus);
        console.log('');

        // Test 2: Generate and save OTP
        console.log('📋 TEST 2: Generate and save OTP');
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);
        
        user.resetPasswordOTP = otp;
        user.resetPasswordOTPExpires = otpExpiry;
        await user.save();
        
        console.log('✅ OTP generated and saved');
        console.log('   - OTP:', otp);
        console.log('   - Expires:', otpExpiry.toLocaleString());
        console.log('');

        // Test 3: Send email
        console.log('📋 TEST 3: Send password reset email');
        try {
            await emailService.sendPasswordResetOTP(
                user.email,
                otp,
                user.profile.firstName || 'User'
            );
            console.log('✅ Email sent successfully');
            console.log('   - To:', user.email);
            console.log('   - OTP:', otp);
        } catch (emailError) {
            console.log('❌ Email failed:', emailError.message);
            throw emailError;
        }
        console.log('');

        // Test 4: Verify OTP
        console.log('📋 TEST 4: Verify OTP');
        const savedUser = await User.findById(user._id);
        
        if (savedUser.resetPasswordOTP === otp) {
            console.log('✅ OTP matches');
        } else {
            console.log('❌ OTP mismatch');
            console.log('   - Expected:', otp);
            console.log('   - Saved:', savedUser.resetPasswordOTP);
        }
        
        if (new Date() < savedUser.resetPasswordOTPExpires) {
            console.log('✅ OTP not expired');
            const remainingTime = Math.floor((savedUser.resetPasswordOTPExpires - new Date()) / 1000 / 60);
            console.log('   - Remaining time:', remainingTime, 'minutes');
        } else {
            console.log('❌ OTP expired');
        }
        console.log('');

        // Summary
        console.log('═══════════════════════════════════════');
        console.log('✅ ALL TESTS PASSED');
        console.log('═══════════════════════════════════════');
        console.log('\n📧 Check your email at:', testEmail);
        console.log('🔑 Your OTP is:', otp);
        console.log('⏰ Valid for: 10 minutes');
        console.log('\n🔗 Visit: http://localhost:3000/auth/forgot-password');
        console.log('   1. Enter email:', testEmail);
        console.log('   2. Click "Send Reset Code"');
        console.log('   3. Enter OTP:', otp);
        console.log('   4. Set new password');
        console.log('');

        process.exit(0);
    } catch (error) {
        console.error('\n❌ TEST FAILED');
        console.error('Error:', error.message);
        console.error(error.stack);
        process.exit(1);
    }
}

testForgotPassword();
