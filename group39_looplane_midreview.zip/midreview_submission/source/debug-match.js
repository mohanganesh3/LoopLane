const routeMatching = require('./utils/routeMatching');
const helpers = require('./utils/helpers');

const pickup = [80.1360317, 13.5837772];
const dropoff = [80.4541588, 16.2915189];

const rideRoute = {
  geometry: {
    coordinates: []
  },
  distance: 303.83
};

const fs = require('fs');
const data = fs.readFileSync('./debug-route.json', 'utf-8');
const coords = JSON.parse(data);
rideRoute.geometry.coordinates = coords; 

const result = routeMatching.matchRoutes({ pickup, dropoff }, rideRoute);
console.log(result);
