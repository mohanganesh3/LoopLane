#!/usr/bin/env node

/**
 * Quick Status Checker
 * Run: node check-status.js
 */

const http = require('http');

console.log('\n╔═══════════════════════════════════════╗');
console.log('║   🔍  SYSTEM STATUS CHECK  🔍        ║');
console.log('╚═══════════════════════════════════════╝\n');

// Check server
function checkServer() {
    return new Promise((resolve) => {
        const req = http.get('http://localhost:3000', (res) => {
            if (res.statusCode === 200 || res.statusCode === 302) {
                console.log('✅ Server is running on port 3000');
                resolve(true);
            } else {
                console.log(`⚠️  Server responded with status ${res.statusCode}`);
                resolve(false);
            }
        });

        req.on('error', () => {
            console.log('❌ Server is NOT running');
            console.log('   Start with: npm start');
            resolve(false);
        });

        req.setTimeout(5000, () => {
            console.log('⏱️  Server timeout - might be slow');
            req.destroy();
            resolve(false);
        });
    });
}

// Check forgot password endpoint
function checkForgotPassword() {
    return new Promise((resolve) => {
        const postData = JSON.stringify({ email: 'test@example.com' });
        
        const options = {
            hostname: 'localhost',
            port: 3000,
            path: '/auth/forgot-password',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': postData.length
            }
        };

        const req = http.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const json = JSON.parse(data);
                    if (json.success) {
                        console.log('✅ Forgot password endpoint working');
                    } else {
                        console.log('⚠️  Forgot password returned error');
                    }
                } catch (e) {
                    console.log('⚠️  Could not parse response');
                }
                resolve(true);
            });
        });

        req.on('error', () => {
            console.log('❌ Forgot password endpoint error');
            resolve(false);
        });

        req.setTimeout(5000, () => {
            console.log('⏱️  Forgot password timeout');
            req.destroy();
            resolve(false);
        });

        req.write(postData);
        req.end();
    });
}

// Check MongoDB
async function checkDatabase() {
    try {
        require('dotenv').config();
        const mongoose = require('mongoose');
        
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/lane', {
            serverSelectionTimeoutMS: 3000
        });
        
        console.log('✅ MongoDB connected');
        await mongoose.connection.close();
        return true;
    } catch (error) {
        console.log('❌ MongoDB connection failed');
        return false;
    }
}

// Run all checks
async function runChecks() {
    console.log('🔍 Checking system components...\n');
    
    const serverOk = await checkServer();
    
    if (serverOk) {
        await checkForgotPassword();
    }
    
    console.log('\n🔍 Checking database...\n');
    await checkDatabase();
    
    console.log('\n═══════════════════════════════════════');
    console.log('✅ Status check complete\n');
    console.log('📖 Next steps:');
    console.log('   1. Visit: http://localhost:3000/auth/forgot-password');
    console.log('   2. Open browser console (F12)');
    console.log('   3. Look for emoji logs (🔵 ✅ ❌)');
    console.log('');
    
    process.exit(0);
}

runChecks();
