/**
 * Test complete password reset flow end-to-end
 */

require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const emailService = require('./utils/emailService');
const helpers = require('./utils/helpers');

async function testCompleteFlow() {
    try {
        console.log('\n🧪 ===== TESTING COMPLETE PASSWORD RESET FLOW =====\n');
        
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('✅ Connected to MongoDB');
        
        const testEmail = 'mohanganesh.g23@iiits.in';
        
        // Step 1: Find user
        console.log('\n📌 STEP 1: Finding user...');
        const user = await User.findOne({ email: testEmail });
        
        if (!user) {
            console.log('❌ User not found');
            process.exit(1);
        }
        
        console.log(`✅ User found: ${user._id}`);
        console.log(`   Name: ${user.profile.firstName} ${user.profile.lastName}`);
        console.log(`   Email: ${user.email}`);
        console.log(`   Created: ${user.createdAt}`);
        console.log(`   Email Verified: ${user.emailVerified}`);
        
        // Step 2: Check if resetPasswordOTP exists
        console.log('\n📌 STEP 2: Checking stored OTP...');
        if (user.resetPasswordOTP) {
            console.log(`✅ OTP exists: ${user.resetPasswordOTP}`);
            console.log(`   Expires: ${user.resetPasswordOTPExpires}`);
            
            const now = new Date();
            const expiry = new Date(user.resetPasswordOTPExpires);
            const isExpired = now > expiry;
            
            console.log(`   Current time: ${now.toISOString()}`);
            console.log(`   Is expired: ${isExpired ? '❌ YES' : '✅ NO'}`);
            
            if (!isExpired) {
                const minutesLeft = Math.floor((expiry - now) / 1000 / 60);
                console.log(`   Time remaining: ${minutesLeft} minutes`);
            }
        } else {
            console.log('❌ No OTP found in database');
        }
        
        // Step 3: Test password reset with the OTP
        if (user.resetPasswordOTP && new Date() < user.resetPasswordOTPExpires) {
            console.log('\n📌 STEP 3: Testing password reset...');
            console.log(`   Using OTP: ${user.resetPasswordOTP}`);
            
            const testNewPassword = 'NewTest@123';
            const oldPasswordHash = user.password;
            
            // Simulate the reset password process
            user.password = testNewPassword;
            user.resetPasswordOTP = undefined;
            user.resetPasswordOTPExpires = undefined;
            user.passwordResetToken = undefined;
            user.passwordResetExpires = undefined;
            
            await user.save();
            
            console.log('✅ Password updated successfully');
            console.log(`   Old hash: ${oldPasswordHash.substring(0, 20)}...`);
            console.log(`   New hash: ${user.password.substring(0, 20)}...`);
            console.log('   OTP fields cleared');
            
            // Step 4: Test login with new password
            console.log('\n📌 STEP 4: Testing login with new password...');
            const isPasswordValid = await user.comparePassword(testNewPassword);
            console.log(`   Password validation: ${isPasswordValid ? '✅ SUCCESS' : '❌ FAILED'}`);
            
            // Restore old password for testing
            console.log('\n📌 STEP 5: Restoring original password...');
            user.password = 'Test@123'; // Assuming this was the original
            await user.save();
            console.log('✅ Password restored');
            
            // Generate a new OTP for further testing
            console.log('\n📌 STEP 6: Generating fresh OTP for testing...');
            const otp = helpers.generateOTP();
            const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);
            
            user.resetPasswordOTP = otp;
            user.resetPasswordOTPExpires = otpExpiry;
            await user.save();
            
            console.log(`✅ New OTP generated: ${otp}`);
            console.log(`   Expires at: ${otpExpiry.toISOString()}`);
        } else {
            console.log('\n⚠️  STEP 3-6: Skipped (no valid OTP available)');
            
            // Generate OTP for testing
            console.log('\n📌 Generating new OTP...');
            const otp = helpers.generateOTP();
            const otpExpiry = new Date(Date.now() + 10 * 60 * 1000);
            
            user.resetPasswordOTP = otp;
            user.resetPasswordOTPExpires = otpExpiry;
            await user.save();
            
            console.log(`✅ OTP generated: ${otp}`);
            console.log(`   Expires at: ${otpExpiry.toISOString()}`);
        }
        
        // Step 7: Verify complete flow
        console.log('\n📌 STEP 7: Final verification...');
        const updatedUser = await User.findById(user._id);
        console.log('✅ User data after updates:');
        console.log(`   Email: ${updatedUser.email}`);
        console.log(`   Email Verified: ${updatedUser.emailVerified}`);
        console.log(`   Has OTP: ${updatedUser.resetPasswordOTP ? 'YES' : 'NO'}`);
        console.log(`   OTP: ${updatedUser.resetPasswordOTP || 'N/A'}`);
        console.log(`   OTP Expires: ${updatedUser.resetPasswordOTPExpires || 'N/A'}`);
        
        console.log('\n✅ ===== ALL TESTS PASSED =====\n');
        console.log('🎯 READY TO TEST IN BROWSER:');
        console.log('   1. Go to: http://localhost:3000/auth/forgot-password');
        console.log(`   2. Enter email: ${testEmail}`);
        console.log(`   3. Use OTP: ${updatedUser.resetPasswordOTP}`);
        console.log('   4. Set new password and submit');
        console.log('   5. Login with new password\n');
        
    } catch (error) {
        console.error('\n❌ ERROR:', error.message);
        console.error(error.stack);
    } finally {
        await mongoose.disconnect();
        console.log('👋 Disconnected from MongoDB');
        process.exit(0);
    }
}

testCompleteFlow();
