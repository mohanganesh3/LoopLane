/**
 * Test script to verify carbonSaved fix
 */

const carbonCalculator = require('./utils/carbonCalculator');

console.log('='.repeat(60));
console.log('TESTING CARBON CALCULATOR');
console.log('='.repeat(60));

// Test 1: Calculate carbon saved
const distance = 344; // km (approximate Tada to Guntur)
const vehicleType = 'SEDAN';
const passengers = 1;

console.log('\nTest Input:');
console.log('- Distance:', distance, 'km');
console.log('- Vehicle Type:', vehicleType);
console.log('- Passengers:', passengers);

const carbonData = carbonCalculator.calculateCarbonSaved(distance, vehicleType, passengers);

console.log('\nCarbon Data Returned:');
console.log(JSON.stringify(carbonData, null, 2));

console.log('\nType Checks:');
console.log('- carbonData is object:', typeof carbonData === 'object');
console.log('- carbonData.totalSaved:', carbonData.totalSaved);
console.log('- typeof carbonData.totalSaved:', typeof carbonData.totalSaved);
console.log('- carbonData.totalSaved.toFixed(1):', carbonData.totalSaved.toFixed(1));

console.log('\n✅ All tests passed!');
console.log('='.repeat(60));
