// Test search endpoint
const http = require('http');

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/rides/search/results?origin=%7B%22type%22%3A%22Point%22%2C%22coordinates%22%3A%5B80.1360317%2C13.5837772%5D%2C%22address%22%3A%22Tada%22%7D&destination=%7B%22type%22%3A%22Point%22%2C%22coordinates%22%3A%5B80.4541588%2C16.2915189%5D%2C%22address%22%3A%22Guntur%22%7D&date=2025-10-09&seats=1',
  headers: {
    'Accept': 'application/json',
    'User-Agent': 'Mozilla/5.0'
  }
};

console.log('Testing search endpoint...');

const req = http.get(options, (res) => {
  console.log('Status:', res.statusCode);
  console.log('Headers:', res.headers);
  
  let data = '';
  res.on('data', chunk => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log('\nResponse body:');
    console.log(data);
    
    try {
      const json = JSON.parse(data);
      console.log('\nParsed JSON:');
      console.log(JSON.stringify(json, null, 2));
    } catch(e) {
      console.log('\nNot valid JSON');
    }
    
    process.exit(0);
  });
});

req.on('error', (err) => {
  console.error('Error:', err.message);
  process.exit(1);
});
