#!/bin/bash
# Fix all populate statements to use correct User schema fields

FILE="/Users/mohanganesh/LANE/controllers/chatController.js"

# Replace all instances of 'name profilePhoto' with 'profile email phone'
sed -i '' "s/'name profilePhoto'/'profile email phone'/g" "$FILE"
sed -i '' "s/'name profilePhoto email phoneNumber'/'profile email phone'/g" "$FILE"
sed -i '' "s/'name profilePhoto email'/'profile email phone'/g" "$FILE"
sed -i '' "s/'name profilePhoto email phoneNumber profile'/'profile email phone'/g" "$FILE"
sed -i '' "s/'name profilePhoto profile'/'profile'/g" "$FILE"

echo "✅ Fixed chat controller populate statements"
